package sac.stats;

/**
 * Type of operation for statistics.
 * 
 * @author Przemysław Klęsk (<a href="mailto: pklesk@wi.zut.edu.pl">wi.zut.edu.pl</a>)
 * @author Marcin Korzeń (<a href="mailto: mkorzen@wi.zut.edu.pl">wi.zut.edu.pl</a>)
 */
public enum StatsOperationType {
	MEAN, VARIANCE, COUNT, MIN, MAX
}
